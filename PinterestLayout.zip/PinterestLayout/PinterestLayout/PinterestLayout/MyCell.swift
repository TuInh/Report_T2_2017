//
//  MyCell.swift
//  PinterestLayout
//
//  Created by Le Thi Van Anh on 2/24/17.
//  Copyright © 2017 Le Thi Van Anh. All rights reserved.
//

import UIKit

class MyCell: UICollectionViewCell {
    
    @IBOutlet weak var mImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
   
 }
